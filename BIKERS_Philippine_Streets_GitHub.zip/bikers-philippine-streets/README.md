# BIKERS: Philippine Streets

A beginner-friendly 3D cycling browser game prototype set on a stylized Philippine barangay road.

## Files
- `index.html` — page structure and HUD
- `style.css` — responsive layout and mobile controls
- `script.js` — Three.js 3D world, bicycle, keyboard and touch controls

## Run locally
Because `script.js` uses JavaScript modules, open the project through a local web server rather than opening `index.html` directly. For example, in VS Code install the Live Server extension and click **Go Live**.

The game loads Three.js from jsDelivr, so an internet connection is needed.

## Publish with GitHub Pages
1. Sign in at https://github.com/
2. Create a new public repository named `bikers-philippine-streets`.
3. Upload `index.html`, `style.css`, and `script.js` to the repository root.
4. Open the repository's **Settings** → **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then click **Save**.
7. Wait for the Pages deployment to finish. Your URL will look like:
   `https://YOUR-USERNAME.github.io/bikers-philippine-streets/`

## Controls
- W / Up arrow: pedal / accelerate
- S / Down arrow: brake
- A / Left arrow: steer left
- D / Right arrow: steer right
- Mobile: use the on-screen arrow, brake, and pedal buttons

## Notes
This is a starter prototype with simple procedural 3D shapes, not a realistic simulator. The first load needs internet access to download Three.js.
